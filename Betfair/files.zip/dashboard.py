"""
Live Monitoring Dashboard (Flask).

Runs a lightweight web server that displays:
  - Portfolio state (bankroll, P&L, win rate)
  - Recent arbitrage opportunities
  - Odds comparison grid
  - Trade log
  - Equity curve

Run alongside the scanner:
    python dashboard.py &
    python main.py        # or python simulate.py

Then open http://localhost:5050 in your browser.
"""
from __future__ import annotations
import json
import os
from datetime import datetime
from pathlib import Path

try:
    from flask import Flask, jsonify, render_template_string
except ImportError:
    print("Flask not installed. Run: pip install flask")
    print("Then re-run: python dashboard.py")
    exit(1)

from config import STRATEGY

app = Flask(__name__)

DASHBOARD_HTML = r"""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Arb Scanner Dashboard</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;700&family=DM+Sans:wght@400;500;700&display=swap');

  * { margin: 0; padding: 0; box-sizing: border-box; }

  :root {
    --bg: #0a0e17;
    --surface: #111827;
    --surface2: #1a2332;
    --border: #1e2d3d;
    --text: #e2e8f0;
    --text-dim: #64748b;
    --green: #10b981;
    --green-bg: rgba(16, 185, 129, 0.08);
    --red: #ef4444;
    --red-bg: rgba(239, 68, 68, 0.08);
    --blue: #3b82f6;
    --amber: #f59e0b;
    --purple: #8b5cf6;
  }

  body {
    font-family: 'DM Sans', sans-serif;
    background: var(--bg);
    color: var(--text);
    min-height: 100vh;
    padding: 20px;
  }

  .header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 24px;
    padding-bottom: 16px;
    border-bottom: 1px solid var(--border);
  }

  .header h1 {
    font-family: 'JetBrains Mono', monospace;
    font-size: 18px;
    font-weight: 500;
    letter-spacing: -0.5px;
  }

  .header h1 span { color: var(--green); }

  .status-dot {
    width: 8px; height: 8px;
    border-radius: 50%;
    background: var(--green);
    display: inline-block;
    margin-right: 8px;
    animation: pulse 2s infinite;
  }

  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.4; }
  }

  .grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 12px;
    margin-bottom: 24px;
  }

  .card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 16px;
  }

  .card-label {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: var(--text-dim);
    margin-bottom: 6px;
  }

  .card-value {
    font-family: 'JetBrains Mono', monospace;
    font-size: 24px;
    font-weight: 700;
  }

  .card-value.positive { color: var(--green); }
  .card-value.negative { color: var(--red); }

  .card-sub {
    font-family: 'JetBrains Mono', monospace;
    font-size: 12px;
    color: var(--text-dim);
    margin-top: 4px;
  }

  .section-title {
    font-family: 'JetBrains Mono', monospace;
    font-size: 13px;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    color: var(--text-dim);
    margin-bottom: 12px;
    margin-top: 24px;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    font-family: 'JetBrains Mono', monospace;
    font-size: 12px;
  }

  th {
    text-align: left;
    padding: 8px 12px;
    border-bottom: 1px solid var(--border);
    color: var(--text-dim);
    font-weight: 500;
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 1px;
  }

  td {
    padding: 8px 12px;
    border-bottom: 1px solid rgba(30, 45, 61, 0.5);
  }

  tr:hover { background: var(--surface2); }

  .tag {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 10px;
    font-weight: 500;
    text-transform: uppercase;
  }

  .tag-bf { background: #1e3a5f; color: #60a5fa; }
  .tag-smk { background: #1a3329; color: #34d399; }
  .tag-edge { background: var(--green-bg); color: var(--green); }

  .equity-bar {
    height: 4px;
    background: var(--green);
    border-radius: 2px;
    transition: width 0.5s ease;
    margin-top: 8px;
  }

  #equity-chart {
    width: 100%;
    height: 120px;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 12px;
    margin-bottom: 24px;
  }

  .no-data {
    text-align: center;
    padding: 40px;
    color: var(--text-dim);
    font-style: italic;
  }

  .refresh-info {
    font-size: 11px;
    color: var(--text-dim);
  }
</style>
</head>
<body>
  <div class="header">
    <h1><span>⚡</span> ARB SCANNER <span>|</span> PAPER TRADE DASHBOARD</h1>
    <div class="refresh-info">
      <span class="status-dot"></span>
      Auto-refresh: 3s | <span id="lastUpdate">—</span>
    </div>
  </div>

  <div class="grid" id="statsGrid">
    <div class="card">
      <div class="card-label">Bankroll</div>
      <div class="card-value" id="bankroll">£—</div>
      <div class="card-sub" id="bankrollStart">start: £—</div>
    </div>
    <div class="card">
      <div class="card-label">Total P&L</div>
      <div class="card-value" id="pnl">£—</div>
      <div class="card-sub" id="pnlPct">—%</div>
    </div>
    <div class="card">
      <div class="card-label">Win Rate</div>
      <div class="card-value" id="winRate">—%</div>
      <div class="card-sub" id="tradeCount">0 trades</div>
    </div>
    <div class="card">
      <div class="card-label">Max Drawdown</div>
      <div class="card-value" id="maxDD">—%</div>
      <div class="card-sub" id="peakBankroll">peak: £—</div>
    </div>
    <div class="card">
      <div class="card-label">Open Positions</div>
      <div class="card-value" id="openPos">0</div>
      <div class="card-sub" id="cooldowns">cooldowns: 0</div>
    </div>
  </div>

  <div class="section-title">Equity Curve</div>
  <canvas id="equity-chart"></canvas>

  <div class="section-title">Recent Trades</div>
  <div class="card" style="overflow-x: auto;">
    <table>
      <thead>
        <tr>
          <th>Time</th>
          <th>Event</th>
          <th>Runner</th>
          <th>Back</th>
          <th>Lay</th>
          <th>Stake</th>
          <th>P&L</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody id="tradeTable">
        <tr><td colspan="8" class="no-data">No trades yet — start the scanner</td></tr>
      </tbody>
    </table>
  </div>

  <script>
    async function fetchData() {
      try {
        const resp = await fetch('/api/state');
        const data = await resp.json();

        // Stats
        const s = data.portfolio;
        document.getElementById('bankroll').textContent = '£' + s.bankroll.toFixed(2);
        document.getElementById('bankroll').className = 'card-value ' + (s.bankroll >= s.initial_bankroll ? 'positive' : 'negative');
        document.getElementById('bankrollStart').textContent = 'start: £' + s.initial_bankroll.toFixed(2);

        const pnlSign = s.total_pnl >= 0 ? '+' : '';
        document.getElementById('pnl').textContent = pnlSign + '£' + s.total_pnl.toFixed(2);
        document.getElementById('pnl').className = 'card-value ' + (s.total_pnl >= 0 ? 'positive' : 'negative');
        document.getElementById('pnlPct').textContent = pnlSign + s.total_pnl_pct.toFixed(1) + '%';

        document.getElementById('winRate').textContent = s.win_rate.toFixed(0) + '%';
        document.getElementById('tradeCount').textContent = s.total_trades + ' trades (W:' + s.winning_trades + ' L:' + s.losing_trades + ')';

        document.getElementById('maxDD').textContent = s.max_drawdown_pct.toFixed(1) + '%';
        document.getElementById('maxDD').className = 'card-value ' + (s.max_drawdown_pct > 5 ? 'negative' : '');
        document.getElementById('peakBankroll').textContent = 'peak: £' + s.peak_bankroll.toFixed(2);

        document.getElementById('openPos').textContent = s.open_positions;

        // Trades table
        const trades = data.trades || [];
        const tbody = document.getElementById('tradeTable');
        if (trades.length === 0) {
          tbody.innerHTML = '<tr><td colspan="8" class="no-data">No trades yet — start the scanner</td></tr>';
        } else {
          tbody.innerHTML = trades.slice(-30).reverse().map(t => {
            const time = t.timestamp ? new Date(t.timestamp).toLocaleTimeString() : '—';
            const backTag = t.back_exchange === 'betfair' ? 'bf' : 'smk';
            const layTag = t.lay_exchange === 'betfair' ? 'bf' : 'smk';
            const pnlClass = (t.actual_profit || 0) >= 0 ? 'positive' : 'negative';
            const pnlStr = (t.actual_profit || 0) >= 0
              ? '+£' + (t.actual_profit || 0).toFixed(2)
              : '-£' + Math.abs(t.actual_profit || 0).toFixed(2);
            return '<tr>' +
              '<td>' + time + '</td>' +
              '<td>' + (t.event_name || '—').substring(0, 28) + '</td>' +
              '<td>' + (t.runner_name || '—') + '</td>' +
              '<td><span class="tag tag-' + backTag + '">' + backTag.toUpperCase() + '</span> @' + (t.back_price || 0).toFixed(2) + '</td>' +
              '<td><span class="tag tag-' + layTag + '">' + layTag.toUpperCase() + '</span> @' + (t.lay_price || 0).toFixed(2) + '</td>' +
              '<td>£' + (t.back_stake || 0).toFixed(2) + '</td>' +
              '<td style="color:var(--' + (pnlClass === 'positive' ? 'green' : 'red') + ')">' + pnlStr + '</td>' +
              '<td>' + (t.status || 'open') + '</td>' +
              '</tr>';
          }).join('');
        }

        // Equity curve
        drawEquity(data.equity || []);

        document.getElementById('lastUpdate').textContent = new Date().toLocaleTimeString();
      } catch (e) {
        console.error('Fetch error:', e);
      }
    }

    function drawEquity(points) {
      const canvas = document.getElementById('equity-chart');
      const ctx = canvas.getContext('2d');
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
      const W = rect.width;
      const H = rect.height;

      ctx.clearRect(0, 0, W, H);

      if (points.length < 2) return;

      const min = Math.min(...points) * 0.98;
      const max = Math.max(...points) * 1.02;
      const range = max - min || 1;

      // Grid lines
      ctx.strokeStyle = '#1e2d3d';
      ctx.lineWidth = 0.5;
      for (let i = 0; i < 4; i++) {
        const y = (H / 4) * i;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(W, y);
        ctx.stroke();
      }

      // Line
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 2;
      ctx.lineJoin = 'round';
      ctx.beginPath();
      points.forEach((p, i) => {
        const x = (i / (points.length - 1)) * W;
        const y = H - ((p - min) / range) * H;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.stroke();

      // Fill
      const lastX = W;
      const lastY = H - ((points[points.length - 1] - min) / range) * H;
      ctx.lineTo(lastX, H);
      ctx.lineTo(0, H);
      ctx.closePath();
      const grad = ctx.createLinearGradient(0, 0, 0, H);
      grad.addColorStop(0, 'rgba(16, 185, 129, 0.15)');
      grad.addColorStop(1, 'rgba(16, 185, 129, 0)');
      ctx.fillStyle = grad;
      ctx.fill();
    }

    fetchData();
    setInterval(fetchData, 3000);
  </script>
</body>
</html>
"""


def load_trades() -> list[dict]:
    """Load trades from JSONL log, deduplicating by ID (keep latest)."""
    path = Path(STRATEGY.trades_log_path)
    if not path.exists():
        return []
    by_id = {}
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    t = json.loads(line)
                    by_id[t["id"]] = t
                except (json.JSONDecodeError, KeyError):
                    continue
    return sorted(by_id.values(), key=lambda t: t.get("timestamp", ""))


def compute_state() -> dict:
    """Build the full dashboard state from trade logs."""
    trades = load_trades()

    resolved = [t for t in trades if t.get("status") != "open"]
    open_trades = [t for t in trades if t.get("status") == "open"]

    total_pnl = sum(t.get("actual_profit", 0) for t in resolved)
    bankroll = STRATEGY.initial_bankroll + total_pnl
    winners = sum(1 for t in resolved if t.get("actual_profit", 0) > 0)
    losers = len(resolved) - winners

    # Equity curve
    equity = [STRATEGY.initial_bankroll]
    running = STRATEGY.initial_bankroll
    peak = running
    max_dd = 0.0
    for t in resolved:
        running += t.get("actual_profit", 0)
        equity.append(round(running, 2))
        if running > peak:
            peak = running
        dd = (peak - running) / peak if peak > 0 else 0
        if dd > max_dd:
            max_dd = dd

    portfolio = {
        "bankroll": round(bankroll, 2),
        "initial_bankroll": STRATEGY.initial_bankroll,
        "total_pnl": round(total_pnl, 2),
        "total_pnl_pct": round((total_pnl / STRATEGY.initial_bankroll) * 100, 2),
        "total_trades": len(trades),
        "winning_trades": winners,
        "losing_trades": losers,
        "win_rate": round(winners / max(winners + losers, 1) * 100, 1),
        "open_positions": len(open_trades),
        "peak_bankroll": round(peak, 2),
        "max_drawdown_pct": round(max_dd * 100, 2),
    }

    return {
        "portfolio": portfolio,
        "trades": trades[-50:],
        "equity": equity,
    }


@app.route("/")
def index():
    return render_template_string(DASHBOARD_HTML)


@app.route("/api/state")
def api_state():
    return jsonify(compute_state())


if __name__ == "__main__":
    print("Starting dashboard at http://localhost:5050")
    print("Make sure the scanner is running in another terminal.")
    app.run(host="0.0.0.0", port=5050, debug=False)
