"""
Post-Session Analysis: load trade logs and generate performance metrics.

Run: python analyse.py
"""
from __future__ import annotations
import json
import sys
from datetime import datetime
from pathlib import Path
from collections import defaultdict

from config import STRATEGY


def load_trades(path: str) -> list[dict]:
    trades = []
    p = Path(path)
    if not p.exists():
        print(f"No trade log found at {path}")
        return trades
    with open(p) as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    trades.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return trades


def analyse():
    trades = load_trades(STRATEGY.trades_log_path)
    if not trades:
        print("No trades to analyse. Run the scanner or simulation first.")
        return

    # Deduplicate (keep latest version of each trade ID)
    by_id = {}
    for t in trades:
        by_id[t["id"]] = t
    trades = list(by_id.values())

    resolved = [t for t in trades if t.get("status") != "open"]
    open_trades = [t for t in trades if t.get("status") == "open"]

    total_profit = sum(t.get("actual_profit", 0) for t in resolved)
    profits = [t.get("actual_profit", 0) for t in resolved]

    print("=" * 60)
    print("  TRADE ANALYSIS REPORT")
    print("=" * 60)
    print(f"  Total trades logged: {len(trades)}")
    print(f"  Resolved: {len(resolved)}")
    print(f"  Open: {len(open_trades)}")
    print()

    if resolved:
        winners = [p for p in profits if p > 0]
        losers = [p for p in profits if p <= 0]

        print(f"  PERFORMANCE")
        print(f"  Total P&L: £{total_profit:.2f}")
        print(f"  Avg profit per trade: £{total_profit / len(resolved):.2f}")
        print(f"  Winners: {len(winners)}  Losers: {len(losers)}")
        print(f"  Win rate: {len(winners) / len(resolved) * 100:.1f}%")
        if winners:
            print(f"  Avg win: £{sum(winners) / len(winners):.2f}")
            print(f"  Best trade: £{max(winners):.2f}")
        if losers:
            print(f"  Avg loss: £{sum(losers) / len(losers):.2f}")
            print(f"  Worst trade: £{min(losers):.2f}")
        print()

        # Equity curve
        print(f"  EQUITY CURVE")
        running = STRATEGY.initial_bankroll
        peak = running
        max_dd = 0
        for p in profits:
            running += p
            if running > peak:
                peak = running
            dd = (peak - running) / peak if peak > 0 else 0
            if dd > max_dd:
                max_dd = dd
        print(f"  Final bankroll: £{running:.2f}")
        print(f"  Peak bankroll: £{peak:.2f}")
        print(f"  Max drawdown: {max_dd * 100:.1f}%")
        print()

        # By exchange direction
        print(f"  BY DIRECTION")
        by_dir = defaultdict(list)
        for t in resolved:
            key = f"Back:{t.get('back_exchange', '?')} / Lay:{t.get('lay_exchange', '?')}"
            by_dir[key].append(t.get("actual_profit", 0))
        for direction, pnls in by_dir.items():
            print(
                f"  {direction}: {len(pnls)} trades, "
                f"£{sum(pnls):.2f} total, "
                f"£{sum(pnls) / len(pnls):.2f} avg"
            )
        print()

        # By event
        print(f"  BY EVENT")
        by_event = defaultdict(list)
        for t in resolved:
            by_event[t.get("event_name", "Unknown")].append(t.get("actual_profit", 0))
        for event, pnls in sorted(by_event.items(), key=lambda x: -sum(x[1])):
            print(
                f"  {event[:35]}: {len(pnls)} trades, "
                f"£{sum(pnls):.2f}"
            )

    print()
    print("=" * 60)


if __name__ == "__main__":
    analyse()
