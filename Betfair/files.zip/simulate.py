"""
Simulation Mode: test the full pipeline without API credentials.

Generates synthetic odds data that mimics real cross-exchange pricing
behaviour, including occasional arbitrage opportunities created by
simulated pricing lags.

Run: python simulate.py
"""
from __future__ import annotations
import logging
import os
import random
import signal
import sys
import time
from datetime import datetime, timedelta

from config import STRATEGY
from models import Exchange, RunnerOdds, MatchedMarket, ArbOpportunity
from arb_engine import scan_for_arbs
from paper_trader import PaperTrader
from cooldown import CooldownManager

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/simulation.log"),
    ],
)
logger = logging.getLogger("simulator")

RUNNING = True


def signal_handler(sig, frame):
    global RUNNING
    RUNNING = False


signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)


# ──────────────────────────────────────────────
# Synthetic data generators
# ──────────────────────────────────────────────
SIMULATED_EVENTS = [
    {
        "event_name": "Arsenal v Chelsea",
        "market_name": "Match Odds",
        "runners": [
            {"name": "Arsenal", "true_prob": 0.45},
            {"name": "Draw", "true_prob": 0.28},
            {"name": "Chelsea", "true_prob": 0.27},
        ],
    },
    {
        "event_name": "Real Madrid v Barcelona",
        "market_name": "Match Odds",
        "runners": [
            {"name": "Real Madrid", "true_prob": 0.40},
            {"name": "Draw", "true_prob": 0.30},
            {"name": "Barcelona", "true_prob": 0.30},
        ],
    },
    {
        "event_name": "Djokovic v Alcaraz",
        "market_name": "Match Winner",
        "runners": [
            {"name": "Djokovic", "true_prob": 0.48},
            {"name": "Alcaraz", "true_prob": 0.52},
        ],
    },
    {
        "event_name": "Man City v Liverpool",
        "market_name": "Match Odds",
        "runners": [
            {"name": "Man City", "true_prob": 0.42},
            {"name": "Draw", "true_prob": 0.26},
            {"name": "Liverpool", "true_prob": 0.32},
        ],
    },
    {
        "event_name": "Sinner v Medvedev",
        "market_name": "Match Winner",
        "runners": [
            {"name": "Sinner", "true_prob": 0.55},
            {"name": "Medvedev", "true_prob": 0.45},
        ],
    },
]


def prob_to_odds(prob: float) -> float:
    """Convert probability to decimal odds."""
    if prob <= 0:
        return 100.0
    return round(1.0 / prob, 2)


def betfair_tick(odds: float) -> float:
    """Round to nearest valid Betfair tick."""
    if odds < 2:
        return round(odds * 100) / 100
    elif odds < 3:
        return round(odds * 50) / 50
    elif odds < 4:
        return round(odds * 20) / 20
    elif odds < 6:
        return round(odds * 10) / 10
    elif odds < 10:
        return round(odds * 5) / 5
    elif odds < 20:
        return round(odds * 2) / 2
    else:
        return round(odds)


def generate_odds_pair(
    true_prob: float,
    runner_name: str,
    bf_market_id: str,
    smk_market_id: str,
    bf_sel_id: str,
    smk_con_id: str,
    lag_chance: float = 0.08,  # 8% chance of a lag creating an arb
) -> tuple[RunnerOdds, RunnerOdds]:
    """
    Generate a pair of odds (Betfair + Smarkets) for a runner.

    Most of the time, prices will be close and no arb exists.
    Occasionally (controlled by lag_chance), one exchange 'lags',
    creating a temporary cross-exchange arb.
    """
    fair_odds = prob_to_odds(true_prob)

    # Normal spread: back slightly above fair, lay slightly below
    # Exchange 1: Betfair
    bf_noise = random.gauss(0, 0.02)
    bf_spread = random.uniform(0.01, 0.03)  # 1-3% spread
    bf_back = betfair_tick(fair_odds * (1 + bf_spread / 2 + bf_noise))
    bf_lay = betfair_tick(fair_odds * (1 - bf_spread / 2 + bf_noise))
    # Ensure back > lay
    if bf_back <= bf_lay:
        bf_back = betfair_tick(bf_lay * 1.02)

    # Exchange 2: Smarkets
    smk_noise = random.gauss(0, 0.02)
    smk_spread = random.uniform(0.01, 0.04)
    smk_back = round(fair_odds * (1 + smk_spread / 2 + smk_noise), 2)
    smk_lay = round(fair_odds * (1 - smk_spread / 2 + smk_noise), 2)
    if smk_back <= smk_lay:
        smk_back = round(smk_lay * 1.02, 2)

    # Simulate pricing lag (the magic moment!)
    if random.random() < lag_chance:
        # One exchange hasn't caught up to new information
        lag_direction = random.choice(["bf_high", "smk_high"])
        lag_magnitude = random.uniform(0.03, 0.12)  # 3-12% lag

        if lag_direction == "bf_high":
            # Betfair back price is too high (stale) relative to Smarkets lay
            bf_back = betfair_tick(bf_back * (1 + lag_magnitude))
            # Smarkets lay has already adjusted down
            smk_lay = round(smk_lay * (1 - lag_magnitude * 0.3), 2)
        else:
            # Smarkets back price is too high relative to Betfair lay
            smk_back = round(smk_back * (1 + lag_magnitude), 2)
            bf_lay = betfair_tick(bf_lay * (1 - lag_magnitude * 0.3))

    # Generate liquidity
    bf_back_size = round(random.uniform(10, 500), 2)
    bf_lay_size = round(random.uniform(10, 500), 2)
    smk_back_size = round(random.uniform(5, 200), 2)
    smk_lay_size = round(random.uniform(5, 200), 2)

    bf_odds = RunnerOdds(
        exchange=Exchange.BETFAIR,
        market_id=bf_market_id,
        selection_id=bf_sel_id,
        runner_name=runner_name,
        best_back_price=bf_back,
        best_back_size=bf_back_size,
        best_lay_price=bf_lay,
        best_lay_size=bf_lay_size,
    )

    smk_odds = RunnerOdds(
        exchange=Exchange.SMARKETS,
        market_id=smk_market_id,
        selection_id=smk_con_id,
        runner_name=runner_name,
        best_back_price=smk_back,
        best_back_size=smk_back_size,
        best_lay_price=smk_lay,
        best_lay_size=smk_lay_size,
    )

    return bf_odds, smk_odds


# ──────────────────────────────────────────────
# Dashboard
# ──────────────────────────────────────────────
def print_sim_dashboard(
    trader: PaperTrader,
    scan_count: int,
    arbs_total: int,
    all_arbs: list[ArbOpportunity],
    current_odds: list[tuple[RunnerOdds, RunnerOdds]],
):
    os.system("clear" if os.name != "nt" else "cls")
    summary = trader.get_portfolio_summary()

    print("=" * 80)
    print("  CROSS-EXCHANGE ARB SCANNER — SIMULATION MODE")
    print("=" * 80)
    print(f"  Time: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")
    print(f"  Scan #{scan_count} | Simulated events: {len(SIMULATED_EVENTS)}")
    print("-" * 80)

    pnl_sym = "+" if summary["total_pnl"] >= 0 else ""
    print(f"  PORTFOLIO")
    print(f"  Bankroll: £{summary['bankroll']:.2f}  (start: £{summary['initial_bankroll']:.2f})")
    print(f"  P&L: {pnl_sym}£{summary['total_pnl']:.2f}  ({pnl_sym}{summary['total_pnl_pct']:.1f}%)")
    print(
        f"  Trades: {summary['total_trades']}  "
        f"(W:{summary['winning_trades']} / L:{summary['losing_trades']})  "
        f"Win rate: {summary['win_rate']}%"
    )
    print(f"  Max DD: {summary['max_drawdown_pct']:.1f}%")
    print("-" * 80)

    # Current odds table
    print(f"  LIVE ODDS (simulated)")
    print(
        f"  {'Runner':<22} {'BF Back':>8} {'BF Lay':>8} "
        f"{'SMK Back':>9} {'SMK Lay':>8} {'Cross?':>6}"
    )
    for bf_o, smk_o in current_odds:
        # Check for cross (back on one > lay on other)
        cross = ""
        if bf_o.best_back_price and smk_o.best_lay_price:
            if bf_o.best_back_price > smk_o.best_lay_price:
                cross = "BF>SMK"
        if smk_o.best_back_price and bf_o.best_lay_price:
            if smk_o.best_back_price > bf_o.best_lay_price:
                cross = "SMK>BF"

        print(
            f"  {bf_o.runner_name[:22]:<22} "
            f"{bf_o.best_back_price or 0:>8.2f} {bf_o.best_lay_price or 0:>8.2f} "
            f"{smk_o.best_back_price or 0:>9.2f} {smk_o.best_lay_price or 0:>8.2f} "
            f"{'⚡' + cross if cross else '':>6}"
        )

    print("-" * 80)
    print(f"  ARBITRAGE OPPORTUNITIES: {arbs_total}")

    if all_arbs:
        print(
            f"\n  {'Runner':<22} {'Direction':<18} "
            f"{'Edge%':>6} {'Stake':>7} {'Profit':>8}"
        )
        for arb in all_arbs[-8:]:
            direction = f"B:{arb.back_exchange.value[:3]}@{arb.back_price:.2f} L:{arb.lay_exchange.value[:3]}@{arb.lay_price:.2f}"
            print(
                f"  {arb.runner_name[:22]:<22} {direction:<18} "
                f"{arb.net_edge_pct:>5.1f}% "
                f"£{arb.back_stake:>6.2f} "
                f"£{arb.guaranteed_profit:>7.2f}"
            )

    print()
    print("=" * 80)
    print("  Press Ctrl+C to stop")
    print("=" * 80)


# ──────────────────────────────────────────────
# Simulation loop
# ──────────────────────────────────────────────
def run_simulation():
    logger.info("Starting simulation mode")
    trader = PaperTrader()
    cooldown = CooldownManager(cooldown_seconds=15.0)  # shorter for simulation

    scan_count = 0
    arbs_total = 0
    all_arbs: list[ArbOpportunity] = []

    # Assign IDs to simulated markets/runners
    market_data = []
    for i, event in enumerate(SIMULATED_EVENTS):
        bf_mid = f"BF_{i}"
        smk_mid = f"SMK_{i}"
        runners_info = []
        runner_map = {}
        for j, r in enumerate(event["runners"]):
            bf_sel = f"BF_R_{i}_{j}"
            smk_con = f"SMK_C_{i}_{j}"
            runners_info.append(
                {
                    "name": r["name"],
                    "true_prob": r["true_prob"],
                    "bf_sel_id": bf_sel,
                    "smk_con_id": smk_con,
                }
            )
            runner_map[bf_sel] = smk_con

        matched_market = MatchedMarket(
            event_name=event["event_name"],
            market_name=event["market_name"],
            betfair_market_id=bf_mid,
            smarkets_market_id=smk_mid,
            start_time=datetime.utcnow() + timedelta(hours=random.randint(1, 12)),
        )
        market_data.append(
            {
                "bf_mid": bf_mid,
                "smk_mid": smk_mid,
                "runners_info": runners_info,
                "runner_map": runner_map,
                "matched_market": matched_market,
            }
        )

    while RUNNING:
        try:
            scan_count += 1
            current_odds = []

            for md in market_data:
                bf_odds_list = []
                smk_odds_list = []

                for ri in md["runners_info"]:
                    bf_o, smk_o = generate_odds_pair(
                        true_prob=ri["true_prob"],
                        runner_name=ri["name"],
                        bf_market_id=md["bf_mid"],
                        smk_market_id=md["smk_mid"],
                        bf_sel_id=ri["bf_sel_id"],
                        smk_con_id=ri["smk_con_id"],
                    )
                    bf_odds_list.append(bf_o)
                    smk_odds_list.append(smk_o)
                    current_odds.append((bf_o, smk_o))

                # Scan for arbs
                arbs = scan_for_arbs(
                    bf_odds_list,
                    smk_odds_list,
                    md["runner_map"],
                    md["matched_market"],
                )

                for arb in arbs:
                    event_name = (
                        md["matched_market"].event_name
                        if md.get("matched_market") else "Unknown"
                    )
                    if not cooldown.can_trade(event_name, arb.runner_name):
                        continue
                    trade = trader.execute_paper_trade(arb)
                    if trade:
                        trader.auto_resolve_arb(trade.id)
                        cooldown.record_trade(event_name, arb.runner_name)
                        arbs_total += 1
                        all_arbs.append(arb)

            # Log
            trader.log_snapshot(
                {
                    "mode": "simulation",
                    "scan_count": scan_count,
                    "arbs_found": arbs_total,
                }
            )

            print_sim_dashboard(
                trader, scan_count, arbs_total, all_arbs, current_odds
            )

            time.sleep(STRATEGY.scan_interval_seconds)

        except KeyboardInterrupt:
            break
        except Exception as e:
            logger.error(f"Simulation error: {e}", exc_info=True)
            time.sleep(5)

    print("\n\nFINAL SIMULATION SUMMARY:")
    summary = trader.get_portfolio_summary()
    for k, v in summary.items():
        print(f"  {k}: {v}")
    print(f"\n  Trade log: {STRATEGY.trades_log_path}")
    print(f"  Snapshots: {STRATEGY.snapshots_path}")


if __name__ == "__main__":
    run_simulation()
