"""
Main Scanner: the orchestrator that ties together market data fetching,
matching, arbitrage detection, and paper trading.

Run this script to start the scanner:
    python main.py

It will:
  1. Log in to Betfair and initialise Smarkets client
  2. Fetch upcoming events from both exchanges
  3. Fuzzy-match events and runners across exchanges
  4. Poll for odds at the configured interval
  5. Detect arbitrage opportunities
  6. Execute paper trades when edges exceed threshold
  7. Print live dashboard to terminal
  8. Log everything to data/ directory
"""
from __future__ import annotations
import json
import logging
import os
import signal
import sys
import time
from datetime import datetime
from typing import Optional

from config import STRATEGY
from models import Exchange, MatchedMarket, ArbOpportunity
from betfair_client import BetfairClient
from smarkets_client import SmarketsClient
from matcher import (
    match_events,
    match_runners,
    build_matched_markets,
)
from arb_engine import scan_for_arbs
from paper_trader import PaperTrader
from cooldown import CooldownManager

# ──────────────────────────────────────────────
# Logging setup
# ──────────────────────────────────────────────
logging.basicConfig(
    level=getattr(logging, STRATEGY.log_level),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/scanner.log"),
    ],
)
logger = logging.getLogger("scanner")

# ──────────────────────────────────────────────
# Graceful shutdown
# ──────────────────────────────────────────────
RUNNING = True


def signal_handler(sig, frame):
    global RUNNING
    logger.info("Shutdown signal received, cleaning up...")
    RUNNING = False


signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)


# ──────────────────────────────────────────────
# Dashboard
# ──────────────────────────────────────────────
def print_dashboard(
    trader: PaperTrader,
    scan_count: int,
    arbs_found_total: int,
    last_arbs: list[ArbOpportunity],
    matched_event_count: int,
):
    """Print a live dashboard to terminal."""
    summary = trader.get_portfolio_summary()
    os.system("clear" if os.name != "nt" else "cls")

    print("=" * 78)
    print("  CROSS-EXCHANGE ARBITRAGE SCANNER — PAPER TRADING MODE")
    print("=" * 78)
    print(f"  Time: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")
    print(f"  Scan #{scan_count} | Matched events: {matched_event_count}")
    print("-" * 78)

    # Portfolio
    pnl_symbol = "+" if summary["total_pnl"] >= 0 else ""
    print(f"  PORTFOLIO")
    print(
        f"  Bankroll: £{summary['bankroll']:.2f}  "
        f"(start: £{summary['initial_bankroll']:.2f})"
    )
    print(
        f"  P&L: {pnl_symbol}£{summary['total_pnl']:.2f}  "
        f"({pnl_symbol}{summary['total_pnl_pct']:.1f}%)"
    )
    print(
        f"  Trades: {summary['total_trades']}  "
        f"(W:{summary['winning_trades']} / L:{summary['losing_trades']})  "
        f"Win rate: {summary['win_rate']}%"
    )
    print(
        f"  Open: {summary['open_positions']}  "
        f"Peak: £{summary['peak_bankroll']:.2f}  "
        f"Max DD: {summary['max_drawdown_pct']:.1f}%"
    )
    print("-" * 78)

    # Arb counter
    print(f"  OPPORTUNITIES DETECTED: {arbs_found_total}")
    print(f"  Min edge threshold: {STRATEGY.min_edge_pct}%")

    if last_arbs:
        print()
        print(f"  LATEST OPPORTUNITIES:")
        print(
            f"  {'Runner':<25} {'Back':<15} {'Lay':<15} "
            f"{'Edge%':>6} {'Profit':>8}"
        )
        for arb in last_arbs[-5:]:
            print(
                f"  {arb.runner_name[:25]:<25} "
                f"{arb.back_exchange.value[:3]}@{arb.back_price:.2f}"
                f"{'':>3} "
                f"{arb.lay_exchange.value[:3]}@{arb.lay_price:.2f}"
                f"{'':>3} "
                f"{arb.net_edge_pct:>5.1f}% "
                f"£{arb.guaranteed_profit:>7.2f}"
            )

    # Open positions
    if trader.portfolio.open_positions:
        print()
        print(f"  OPEN POSITIONS:")
        for t in trader.portfolio.open_positions[:5]:
            print(
                f"  [{t.id}] {t.event_name[:30]} - {t.runner_name[:15]} | "
                f"Exp: £{t.expected_profit:.2f}"
            )

    print()
    print("=" * 78)
    print("  Press Ctrl+C to stop")
    print("=" * 78)


# ──────────────────────────────────────────────
# Main loop
# ──────────────────────────────────────────────
def run_scanner():
    """Main scanner loop."""
    logger.info("Starting Cross-Exchange Arbitrage Scanner (Paper Mode)")

    # Initialise clients
    bf_client = BetfairClient()
    smk_client = SmarketsClient()
    trader = PaperTrader()
    cooldown = CooldownManager(cooldown_seconds=120.0)

    # Login to Betfair
    logger.info("Logging in to Betfair...")
    if not bf_client.login():
        logger.error("Failed to login to Betfair. Check credentials in config.py")
        logger.info("Running in SMARKETS-ONLY demo mode (no arb detection)")
        bf_available = False
    else:
        bf_available = True

    scan_count = 0
    arbs_found_total = 0
    all_arbs: list[ArbOpportunity] = []
    last_event_refresh = 0
    EVENT_REFRESH_INTERVAL = 300  # refresh event list every 5 minutes

    # Cached matched data
    matched_pairs = []  # (bf_event, smk_event, score)
    runner_maps = {}  # (bf_market_id, smk_market_id) -> {bf_sel -> smk_con}
    market_pairs = {}  # event key -> [(bf_market, smk_market)]

    while RUNNING:
        try:
            now = time.time()
            scan_count += 1

            # ── Refresh event matching periodically ──
            if now - last_event_refresh > EVENT_REFRESH_INTERVAL:
                logger.info("Refreshing event list...")

                # Fetch events from both exchanges
                smk_events = smk_client.get_all_events_for_sports()

                if bf_available:
                    bf_events_raw = bf_client.get_events()

                    # Match events across exchanges
                    matched_pairs = match_events(bf_events_raw, smk_events)

                    # For each matched event, match markets and runners
                    runner_maps = {}
                    market_pairs = {}

                    for bf_ev, smk_ev, score in matched_pairs:
                        bf_markets = bf_client.get_markets_for_event(
                            bf_ev["event_id"]
                        )
                        smk_markets = smk_client.get_markets_for_event(
                            smk_ev["event_id"]
                        )

                        mkt_matches = build_matched_markets(
                            bf_markets,
                            smk_markets,
                            bf_ev["event_name"],
                        )

                        for bf_m, smk_m, mscore in mkt_matches:
                            # Get runners/contracts
                            bf_runners = bf_m.get("runners", [])
                            smk_contracts = smk_client.get_contracts_for_market(
                                smk_m["market_id"]
                            )

                            r_matches = match_runners(bf_runners, smk_contracts)

                            if r_matches:
                                key = (bf_m["market_id"], smk_m["market_id"])
                                runner_maps[key] = {
                                    bf_r["selection_id"]: smk_c["contract_id"]
                                    for bf_r, smk_c, _ in r_matches
                                }
                                market_pairs[key] = MatchedMarket(
                                    event_name=bf_ev["event_name"],
                                    market_name=bf_m["market_name"],
                                    betfair_market_id=bf_m["market_id"],
                                    smarkets_market_id=smk_m["market_id"],
                                    start_time=bf_m.get("market_start_time"),
                                )

                    logger.info(
                        f"Matched {len(runner_maps)} markets with "
                        f"{sum(len(v) for v in runner_maps.values())} runners"
                    )

                last_event_refresh = now

            # ── Fetch live odds and scan for arbs ──
            if bf_available and runner_maps:
                bf_market_ids = list(set(k[0] for k in runner_maps.keys()))
                smk_market_ids = list(set(k[1] for k in runner_maps.keys()))

                bf_odds = bf_client.get_market_odds(bf_market_ids)
                smk_odds = smk_client.get_market_quotes(smk_market_ids)

                # Index odds by market
                bf_by_market = {}
                for o in bf_odds:
                    bf_by_market.setdefault(o.market_id, []).append(o)

                smk_by_market = {}
                for o in smk_odds:
                    smk_by_market.setdefault(o.market_id, []).append(o)

                # Scan each matched market pair
                scan_arbs = []
                for (bf_mid, smk_mid), rmap in runner_maps.items():
                    bf_market_odds = bf_by_market.get(bf_mid, [])
                    smk_market_odds = smk_by_market.get(smk_mid, [])

                    if bf_market_odds and smk_market_odds:
                        matched_mkt = market_pairs.get((bf_mid, smk_mid))
                        arbs = scan_for_arbs(
                            bf_market_odds,
                            smk_market_odds,
                            rmap,
                            matched_mkt,
                        )
                        scan_arbs.extend(arbs)

                # Execute paper trades
                for arb in scan_arbs:
                    event_name = (
                        arb.matched_market.event_name
                        if arb.matched_market else "Unknown"
                    )
                    # Check cooldown (prevents duplicate trades on same runner)
                    if not cooldown.can_trade(event_name, arb.runner_name):
                        continue
                    trade = trader.execute_paper_trade(arb)
                    if trade:
                        # Auto-resolve arb trades (guaranteed profit)
                        trader.auto_resolve_arb(trade.id)
                        cooldown.record_trade(event_name, arb.runner_name)
                        arbs_found_total += 1
                        all_arbs.append(arb)

                # Periodic cooldown cleanup
                if scan_count % 100 == 0:
                    cooldown.cleanup()

                # Log snapshot
                trader.log_snapshot(
                    {
                        "scan_count": scan_count,
                        "bf_markets_scanned": len(bf_market_ids),
                        "smk_markets_scanned": len(smk_market_ids),
                        "arbs_found": len(scan_arbs),
                        "bf_odds_count": len(bf_odds),
                        "smk_odds_count": len(smk_odds),
                    }
                )

            # ── Print dashboard ──
            print_dashboard(
                trader,
                scan_count,
                arbs_found_total,
                all_arbs,
                len(matched_pairs) if bf_available else 0,
            )

            # ── Sleep until next scan ──
            time.sleep(STRATEGY.scan_interval_seconds)

            # ── Periodic Betfair keep-alive ──
            if bf_available and scan_count % 600 == 0:
                bf_client.keep_alive()

        except KeyboardInterrupt:
            break
        except Exception as e:
            logger.error(f"Scanner error: {e}", exc_info=True)
            time.sleep(10)  # back off on error

    # Cleanup
    logger.info("Shutting down...")
    if bf_available:
        bf_client.logout()

    # Print final summary
    print("\n\nFINAL PORTFOLIO SUMMARY:")
    summary = trader.get_portfolio_summary()
    for k, v in summary.items():
        print(f"  {k}: {v}")


if __name__ == "__main__":
    run_scanner()
