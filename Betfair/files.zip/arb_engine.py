"""
Arbitrage Detection Engine.

Detects cross-exchange arbitrage opportunities where:
  - BACK price on exchange A > LAY price on exchange B (or vice versa)
  - After accounting for commission on both sides

Also detects "value" opportunities where the edge is positive
but not a pure arbitrage (i.e. directional edge from pricing lag).

Maths refresher:
  - Back at decimal odds B, stake S_b: profit if wins = S_b * (B-1), loss if loses = S_b
  - Lay at decimal odds L, stake S_l: profit if loses = S_l, loss if wins = S_l * (L-1)
  - For arb: Back on A, Lay on B for same selection
    - If selection wins:  +S_b*(B-1)*(1-comm_A) - S_l*(L-1)
    - If selection loses: -S_b + S_l*(1-comm_B)
    - Set both equal for guaranteed profit, solve for S_l
"""
from __future__ import annotations
import logging
from typing import Optional

from config import STRATEGY
from models import (
    Exchange,
    RunnerOdds,
    ArbOpportunity,
    MatchedMarket,
)

logger = logging.getLogger(__name__)


def calculate_arb(
    back_odds: RunnerOdds,
    lay_odds: RunnerOdds,
    matched_market: Optional[MatchedMarket] = None,
) -> Optional[ArbOpportunity]:
    """
    Check if there's an arbitrage opportunity between a BACK price on one
    exchange and a LAY price on another.

    For a true cross-exchange arb:
      Back at price B on exchange 1, Lay at price L on exchange 2.
      Edge exists when: B > L (after adjusting for commissions).

    Returns ArbOpportunity if edge >= min_edge_pct, else None.
    """
    B = back_odds.best_back_price
    L = lay_odds.best_lay_price

    if not B or not L or B <= 1 or L <= 1:
        return None

    # Determine commission rates based on which exchange is which
    if back_odds.exchange == Exchange.BETFAIR:
        back_comm = STRATEGY.betfair_commission
        lay_comm = STRATEGY.smarkets_commission
    else:
        back_comm = STRATEGY.smarkets_commission
        lay_comm = STRATEGY.betfair_commission

    # ── Gross edge (before commission) ──
    # If B > L, there's a gross arb
    if B <= L:
        return None

    gross_edge_pct = ((B / L) - 1) * 100

    # ── Net edge (after commission) ──
    # Effective back odds after commission on winnings
    B_eff = 1 + (B - 1) * (1 - back_comm)
    # Effective lay odds after commission on winnings
    L_eff = 1 + (L - 1) / (1 - lay_comm)  # need more to cover lay commission

    # Actually for lay: when you lay and the selection loses, you keep the
    # backer's stake. But commission is on your NET winnings on that market.
    # Simpler: for the lay side, if we lay at L, our liability = S_l * (L-1).
    # If the selection loses, we gain S_l, but pay commission: net gain = S_l * (1 - lay_comm)
    # If the selection wins, we lose S_l * (L - 1)

    # For the back side: if we back at B with stake S_b:
    # If the selection wins: gain = S_b * (B - 1) * (1 - back_comm)
    # If the selection loses: lose S_b

    # For guaranteed profit: set both outcomes equal
    # Win: S_b * (B-1) * (1 - back_comm) - S_l * (L-1) = profit
    # Lose: S_l * (1 - lay_comm) - S_b = profit
    # Set them equal:
    # S_b * (B-1) * (1-back_comm) - S_l * (L-1) = S_l * (1-lay_comm) - S_b
    # S_b * [(B-1)*(1-back_comm) + 1] = S_l * [(L-1) + (1-lay_comm)]
    # S_b * [B - B*back_comm + back_comm] = S_l * [L - lay_comm]
    # S_l / S_b = [B*(1-back_comm) + back_comm] / [L - lay_comm]

    numerator = B * (1 - back_comm) + back_comm  # = B - B*back_comm + back_comm
    denominator = L - lay_comm

    if denominator <= 0:
        return None

    lay_ratio = numerator / denominator  # S_l / S_b

    # Calculate profit per unit back stake
    # Profit if back wins = (B-1)*(1-back_comm) * S_b - (L-1) * S_l
    # Using S_l = lay_ratio * S_b:
    profit_if_wins = (B - 1) * (1 - back_comm) - (L - 1) * lay_ratio
    profit_if_loses = lay_ratio * (1 - lay_comm) - 1

    # Both should be equal (or very close due to rounding)
    guaranteed_profit_per_unit = min(profit_if_wins, profit_if_loses)

    net_edge_pct = guaranteed_profit_per_unit * 100

    if net_edge_pct < STRATEGY.min_edge_pct:
        return None

    # ── Stake sizing ──
    # Determine max stake based on available liquidity
    max_back_from_liquidity = back_odds.best_back_size or 0
    max_lay_from_liquidity = (lay_odds.best_lay_size or 0) / lay_ratio if lay_ratio > 0 else 0

    # Take the minimum of: liquidity, max_stake config, kelly-sized bankroll fraction
    back_stake = min(
        max_back_from_liquidity,
        max_lay_from_liquidity,
        STRATEGY.max_stake,
    )

    if back_stake < STRATEGY.min_stake:
        return None

    lay_stake = back_stake * lay_ratio
    guaranteed_profit = back_stake * guaranteed_profit_per_unit

    opp = ArbOpportunity(
        matched_market=matched_market,
        runner_name=back_odds.runner_name or lay_odds.runner_name,
        back_exchange=back_odds.exchange,
        back_price=B,
        back_size_available=back_odds.best_back_size or 0,
        lay_exchange=lay_odds.exchange,
        lay_price=L,
        lay_size_available=lay_odds.best_lay_size or 0,
        gross_edge_pct=gross_edge_pct,
        net_edge_pct=net_edge_pct,
        back_stake=round(back_stake, 2),
        lay_stake=round(lay_stake, 2),
        guaranteed_profit=round(guaranteed_profit, 2),
    )

    logger.info(
        f"ARB FOUND: {opp.runner_name} | "
        f"Back {opp.back_exchange.value}@{B:.2f} / Lay {opp.lay_exchange.value}@{L:.2f} | "
        f"Net edge: {net_edge_pct:.2f}% | Profit: £{guaranteed_profit:.2f}"
    )

    return opp


def scan_for_arbs(
    bf_odds: list[RunnerOdds],
    smk_odds: list[RunnerOdds],
    runner_map: dict[str, str],  # bf_selection_id -> smk_contract_id
    matched_market: Optional[MatchedMarket] = None,
) -> list[ArbOpportunity]:
    """
    Scan all matched runners for arbitrage opportunities.
    Checks both directions:
      1. Back on Betfair, Lay on Smarkets
      2. Back on Smarkets, Lay on Betfair

    runner_map: mapping from Betfair selection_id to Smarkets contract_id
    """
    opportunities = []

    # Index Smarkets odds by contract_id
    smk_by_id = {o.selection_id: o for o in smk_odds}
    bf_by_id = {o.selection_id: o for o in bf_odds}

    for bf_sel_id, smk_con_id in runner_map.items():
        bf_o = bf_by_id.get(bf_sel_id)
        smk_o = smk_by_id.get(smk_con_id)

        if not bf_o or not smk_o:
            continue

        # Direction 1: Back on Betfair, Lay on Smarkets
        if bf_o.best_back_price and smk_o.best_lay_price:
            arb = calculate_arb(bf_o, smk_o, matched_market)
            if arb:
                opportunities.append(arb)

        # Direction 2: Back on Smarkets, Lay on Betfair
        if smk_o.best_back_price and bf_o.best_lay_price:
            arb = calculate_arb(smk_o, bf_o, matched_market)
            if arb:
                opportunities.append(arb)

    return opportunities
