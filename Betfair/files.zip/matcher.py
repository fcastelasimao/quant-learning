"""
Market Matcher: fuzzy-matches events and runners across Betfair and Smarkets.

This is the hardest part of cross-exchange arbing — different exchanges use
different names for the same event/runner. We use a combination of:
  1. Exact string matching on normalised names
  2. Start-time proximity matching
  3. Fuzzy string matching (difflib)
"""
from __future__ import annotations
import logging
import re
from datetime import datetime, timedelta
from difflib import SequenceMatcher
from typing import Optional

from models import MatchedMarket

logger = logging.getLogger(__name__)

# Minimum similarity ratio to consider two names a match
NAME_SIMILARITY_THRESHOLD = 0.70

# Maximum time difference (minutes) for event start times to be considered same event
MAX_TIME_DIFF_MINUTES = 30


def normalise_name(name: str) -> str:
    """
    Normalise an event/runner name for comparison.
    - Lowercase
    - Strip common prefixes/suffixes
    - Remove punctuation
    - Collapse whitespace
    """
    s = name.lower().strip()
    # Remove common sport-specific suffixes
    s = re.sub(r"\b(fc|afc|utd|united|city|cf|sc|ssc)\b", "", s)
    # Remove punctuation
    s = re.sub(r"[^\w\s]", "", s)
    # Collapse whitespace
    s = re.sub(r"\s+", " ", s).strip()
    return s


def name_similarity(a: str, b: str) -> float:
    """Calculate similarity ratio between two normalised names."""
    na = normalise_name(a)
    nb = normalise_name(b)

    # Exact match after normalisation
    if na == nb:
        return 1.0

    # Check if one contains the other
    if na in nb or nb in na:
        return 0.9

    # Fuzzy match
    return SequenceMatcher(None, na, nb).ratio()


def parse_datetime_safe(dt_val) -> Optional[datetime]:
    """Parse various datetime formats safely."""
    if isinstance(dt_val, datetime):
        return dt_val
    if not dt_val:
        return None
    if isinstance(dt_val, str):
        for fmt in [
            "%Y-%m-%dT%H:%M:%S.%fZ",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%dT%H:%M:%S%z",
        ]:
            try:
                return datetime.strptime(dt_val.replace("+00:00", "Z"), fmt)
            except ValueError:
                continue
    return None


def match_events(
    betfair_events: list[dict],
    smarkets_events: list[dict],
) -> list[tuple[dict, dict, float]]:
    """
    Match Betfair events to Smarkets events.
    Returns list of (bf_event, smk_event, similarity_score) tuples.
    """
    matches = []

    for bf_ev in betfair_events:
        bf_name = bf_ev.get("event_name", "")
        bf_time = parse_datetime_safe(bf_ev.get("open_date"))

        best_match = None
        best_score = 0.0

        for smk_ev in smarkets_events:
            smk_name = smk_ev.get("event_name", "")
            smk_time = parse_datetime_safe(smk_ev.get("start_datetime"))

            # Name similarity
            sim = name_similarity(bf_name, smk_name)

            # Time proximity bonus
            time_bonus = 0.0
            if bf_time and smk_time:
                diff_minutes = abs((bf_time - smk_time).total_seconds()) / 60
                if diff_minutes <= MAX_TIME_DIFF_MINUTES:
                    time_bonus = 0.15 * (1 - diff_minutes / MAX_TIME_DIFF_MINUTES)
                else:
                    # Too far apart in time — skip
                    continue

            total_score = min(sim + time_bonus, 1.0)

            if total_score > best_score:
                best_score = total_score
                best_match = smk_ev

        if best_match and best_score >= NAME_SIMILARITY_THRESHOLD:
            matches.append((bf_ev, best_match, best_score))
            logger.debug(
                f"Matched: '{bf_ev.get('event_name')}' <-> "
                f"'{best_match.get('event_name')}' (score={best_score:.2f})"
            )

    logger.info(f"Matched {len(matches)} events across exchanges")
    return matches


def match_runners(
    bf_runners: list[dict],
    smk_contracts: list[dict],
) -> list[tuple[dict, dict, float]]:
    """
    Match runners/selections between exchanges within a matched market.
    Returns list of (bf_runner, smk_contract, similarity_score).
    """
    matches = []

    for bf_r in bf_runners:
        bf_name = bf_r.get("runner_name", "")
        best_match = None
        best_score = 0.0

        for smk_c in smk_contracts:
            smk_name = smk_c.get("contract_name", "")
            sim = name_similarity(bf_name, smk_name)
            if sim > best_score:
                best_score = sim
                best_match = smk_c

        if best_match and best_score >= NAME_SIMILARITY_THRESHOLD:
            matches.append((bf_r, best_match, best_score))

    return matches


def build_matched_markets(
    bf_markets: list[dict],
    smk_markets: list[dict],
    event_name: str,
) -> list[tuple[dict, dict, float]]:
    """
    Match markets within a matched event.
    Focuses on 'Match Odds' / 'Winner' style markets.
    """
    matches = []

    # Filter to relevant market types
    target_types = {"match_odds", "winner", "moneyline", "match odds", "full_time_result"}

    bf_filtered = [
        m
        for m in bf_markets
        if normalise_name(m.get("market_name", "")) in target_types
        or "match odds" in m.get("market_name", "").lower()
        or "winner" in m.get("market_name", "").lower()
    ]

    smk_filtered = [
        m
        for m in smk_markets
        if normalise_name(m.get("market_name", "")) in target_types
        or "winner" in m.get("market_name", "").lower()
        or "full time" in m.get("market_name", "").lower()
        or m.get("market_type", "").lower() in target_types
    ]

    for bf_m in bf_filtered:
        for smk_m in smk_filtered:
            sim = name_similarity(
                bf_m.get("market_name", ""), smk_m.get("market_name", "")
            )
            # For market names, be more lenient (they're often "Match Odds" vs "Winner")
            if sim >= 0.4:
                matches.append((bf_m, smk_m, sim))

    # If no matches by name, just pair first market from each
    if not matches and bf_filtered and smk_filtered:
        matches.append((bf_filtered[0], smk_filtered[0], 0.5))

    return matches
