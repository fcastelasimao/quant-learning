"""
Smarkets Exchange client using their REST API.
Docs: https://docs.smarkets.com/

Smarkets uses a free REST API with no SSL cert requirements.
Odds are returned as percentages (0-100) which we convert to decimal.
"""
from __future__ import annotations
import logging
from datetime import datetime, timedelta
from typing import Optional

import requests

from config import SMARKETS_API_TOKEN, SMARKETS_BASE_URL, STRATEGY
from models import Exchange, RunnerOdds

logger = logging.getLogger(__name__)

# Smarkets sport slugs mapped to Betfair event type IDs
SPORT_SLUG_MAP = {
    "1": "football",
    "2": "tennis",
    "4": "cricket",
    "7": "horse_racing",
    "7522": "basketball",
}


class SmarketsClient:
    """Client for Smarkets REST API."""

    def __init__(self):
        self.base_url = SMARKETS_BASE_URL
        self.session = requests.Session()
        self.session.headers.update(
            {
                "Accept": "application/json",
                "Content-Type": "application/json",
            }
        )
        if SMARKETS_API_TOKEN and SMARKETS_API_TOKEN != "YOUR_SMARKETS_TOKEN":
            self.session.headers["Authorization"] = f"Session-Token {SMARKETS_API_TOKEN}"

    def _get(self, endpoint: str, params: dict = None) -> dict:
        """Make a GET request to Smarkets API."""
        url = f"{self.base_url}/{endpoint}"
        try:
            resp = self.session.get(url, params=params, timeout=10)
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as e:
            logger.error(f"Smarkets API error on {endpoint}: {e}")
            return {}

    def get_events(self, sport_slug: str = "football") -> list[dict]:
        """
        Get upcoming events for a sport.
        Returns list of event dicts.
        """
        params = {
            "state": "upcoming",
            "type_domain": sport_slug,
            "type_scope": "single_event",
            "limit": 50,
            "sort": "id",
            "start_datetime_min": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S"),
            "start_datetime_max": (
                datetime.utcnow() + timedelta(hours=STRATEGY.hours_until_start)
            ).strftime("%Y-%m-%dT%H:%M:%S"),
        }

        data = self._get("events", params=params)
        events = data.get("events", [])

        results = []
        for ev in events:
            results.append(
                {
                    "event_id": str(ev.get("id", "")),
                    "event_name": ev.get("name", ""),
                    "start_datetime": ev.get("start_datetime", ""),
                    "state": ev.get("state", ""),
                    "slug": ev.get("slug", ""),
                }
            )

        logger.info(f"Smarkets: found {len(results)} {sport_slug} events")
        return results

    def get_markets_for_event(self, event_id: str) -> list[dict]:
        """
        Get markets for a specific event.
        """
        params = {"event_id": event_id, "limit": 20}
        data = self._get("markets", params=params)
        markets = data.get("markets", [])

        results = []
        for mkt in markets:
            results.append(
                {
                    "market_id": str(mkt.get("id", "")),
                    "market_name": mkt.get("name", ""),
                    "slug": mkt.get("slug", ""),
                    "market_type": mkt.get("market_type", {}).get("name", ""),
                    "event_id": event_id,
                }
            )

        return results

    def get_contracts_for_market(self, market_id: str) -> list[dict]:
        """
        Get contracts (runners/selections) for a market.
        """
        params = {"market_id": market_id, "limit": 20}
        data = self._get("contracts", params=params)
        contracts = data.get("contracts", [])

        results = []
        for c in contracts:
            results.append(
                {
                    "contract_id": str(c.get("id", "")),
                    "contract_name": c.get("name", ""),
                    "slug": c.get("slug", ""),
                    "market_id": market_id,
                }
            )

        return results

    def get_market_quotes(self, market_ids: list[str]) -> list[RunnerOdds]:
        """
        Fetch current best back/lay prices for contracts in given markets.

        Smarkets price format (confirmed from docs):
          - Prices are in basis points of percentage: 2500 = 25.00% = 4.0 decimal odds
          - To convert: decimal_odds = 10000 / price_bps
          - Quantities are in 0.01 GBP units: 400000 = £40.00 payout

        Smarkets terminology:
          - "bids" = BUY orders = people backing (want to buy YES)
            → For us: these define the BACK price (we can sell to them)
            → Actually: highest bid = best price we can BACK at (they're buying)
          - "offers" = SELL orders = people laying (want to sell YES)
            → For us: these define the LAY price (we can buy from them)
            → Actually: lowest offer = best price we can LAY at (they're selling)

        Wait — Smarkets uses a "probability exchange" model:
          - BUY (bid) at 25% means you're backing at 4.0 decimal
          - SELL (offer) at 25% means you're laying at 4.0 decimal
          - Best back = highest bid price (highest probability someone will buy at)
          - Best lay = lowest offer price (lowest probability someone will sell at)
        """
        all_odds = []

        for market_id in market_ids:
            # First get contracts
            contracts = self.get_contracts_for_market(market_id)

            if not contracts:
                continue

            # Get quotes for this market
            data = self._get(f"markets/{market_id}/quotes")
            quotes = data.get("quotes", {})

            for contract in contracts:
                cid = contract["contract_id"]
                quote = quotes.get(cid, {})

                best_back = None
                best_back_size = None
                best_lay = None
                best_lay_size = None

                bids = quote.get("bids", [])    # BUY orders (backing)
                offers = quote.get("offers", [])  # SELL orders (laying)

                if bids:
                    # Highest bid = best back price available
                    top_bid = bids[0]
                    price_bps = top_bid.get("price", 0)
                    if price_bps > 0:
                        best_back = 10000.0 / price_bps  # bps → decimal odds
                        # Quantity is in 0.01 GBP payout units
                        best_back_size = top_bid.get("quantity", 0) / 10000.0  # → GBP stake

                if offers:
                    # Lowest offer = best lay price available
                    top_offer = offers[0]
                    price_bps = top_offer.get("price", 0)
                    if price_bps > 0:
                        best_lay = 10000.0 / price_bps
                        best_lay_size = top_offer.get("quantity", 0) / 10000.0

                odds = RunnerOdds(
                    exchange=Exchange.SMARKETS,
                    market_id=market_id,
                    selection_id=cid,
                    runner_name=contract.get("contract_name", ""),
                    best_back_price=best_back,
                    best_back_size=best_back_size,
                    best_lay_price=best_lay,
                    best_lay_size=best_lay_size,
                    timestamp=datetime.utcnow(),
                )
                all_odds.append(odds)

        return all_odds

    def get_all_events_for_sports(self) -> list[dict]:
        """Get events across all configured sports."""
        all_events = []
        for etid in STRATEGY.event_type_ids:
            slug = SPORT_SLUG_MAP.get(etid)
            if slug:
                events = self.get_events(sport_slug=slug)
                for ev in events:
                    ev["sport_slug"] = slug
                    ev["betfair_event_type_id"] = etid
                all_events.extend(events)
        return all_events
