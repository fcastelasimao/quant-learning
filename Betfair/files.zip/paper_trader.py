"""
Paper Trading Engine.

Simulates trade execution, tracks portfolio state, and logs everything
to JSONL files for later analysis.

This does NOT place real bets. It records what WOULD have happened.
"""
from __future__ import annotations
import json
import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Optional

from config import STRATEGY
from models import (
    ArbOpportunity,
    PaperTrade,
    PortfolioState,
    TradeStatus,
    Exchange,
)

logger = logging.getLogger(__name__)


class PaperTrader:
    """Simulates trade execution and tracks paper P&L."""

    def __init__(self):
        self.portfolio = PortfolioState(bankroll=STRATEGY.initial_bankroll)
        self.portfolio.peak_bankroll = STRATEGY.initial_bankroll

        # Ensure data directory exists
        Path(STRATEGY.trades_log_path).parent.mkdir(parents=True, exist_ok=True)
        Path(STRATEGY.snapshots_path).parent.mkdir(parents=True, exist_ok=True)

    def execute_paper_trade(self, opp: ArbOpportunity) -> Optional[PaperTrade]:
        """
        'Execute' an arbitrage opportunity as a paper trade.
        Returns the PaperTrade if executed, None if rejected.
        """
        # Check portfolio constraints
        if len(self.portfolio.open_positions) >= STRATEGY.max_open_positions:
            logger.warning("Max open positions reached, skipping trade")
            return None

        # Check bankroll
        total_cost = opp.back_stake + opp.lay_stake * (opp.lay_price - 1)  # lay liability
        if total_cost > self.portfolio.bankroll * 0.5:  # never risk more than 50% of bankroll
            logger.warning(
                f"Trade cost £{total_cost:.2f} exceeds 50% of bankroll "
                f"£{self.portfolio.bankroll:.2f}, skipping"
            )
            return None

        # Create paper trade
        trade = PaperTrade(
            opportunity_id=opp.id,
            event_name=(
                opp.matched_market.event_name if opp.matched_market else "Unknown"
            ),
            runner_name=opp.runner_name,
            back_exchange=opp.back_exchange,
            back_price=opp.back_price,
            back_stake=opp.back_stake,
            lay_exchange=opp.lay_exchange,
            lay_price=opp.lay_price,
            lay_stake=opp.lay_stake,
            expected_profit=opp.guaranteed_profit,
            status=TradeStatus.OPEN,
        )

        self.portfolio.open_positions.append(trade)
        self.portfolio.total_trades += 1

        # Log trade
        self._log_trade(trade)

        logger.info(
            f"PAPER TRADE EXECUTED: {trade.id} | "
            f"{trade.event_name} - {trade.runner_name} | "
            f"Back {trade.back_exchange.value}@{trade.back_price:.2f} £{trade.back_stake:.2f} | "
            f"Lay {trade.lay_exchange.value}@{trade.lay_price:.2f} £{trade.lay_stake:.2f} | "
            f"Expected profit: £{trade.expected_profit:.2f}"
        )

        return trade

    def resolve_trade(
        self,
        trade_id: str,
        selection_won: bool,
    ) -> Optional[PaperTrade]:
        """
        Resolve a paper trade based on whether the selection won or lost.

        For a properly hedged arb:
          - If selection wins: profit = back_stake * (back_price - 1) * (1 - back_comm) - lay_stake * (lay_price - 1)
          - If selection loses: profit = lay_stake * (1 - lay_comm) - back_stake
        """
        trade = None
        for t in self.portfolio.open_positions:
            if t.id == trade_id:
                trade = t
                break

        if not trade:
            logger.warning(f"Trade {trade_id} not found in open positions")
            return None

        # Determine commissions
        if trade.back_exchange == Exchange.BETFAIR:
            back_comm = STRATEGY.betfair_commission
            lay_comm = STRATEGY.smarkets_commission
        else:
            back_comm = STRATEGY.smarkets_commission
            lay_comm = STRATEGY.betfair_commission

        if selection_won:
            # Back wins: gain from back, lose from lay
            back_profit = trade.back_stake * (trade.back_price - 1) * (1 - back_comm)
            lay_loss = trade.lay_stake * (trade.lay_price - 1)
            actual_profit = back_profit - lay_loss
            trade.status = TradeStatus.WON
        else:
            # Back loses: lose back stake, gain from lay
            lay_profit = trade.lay_stake * (1 - lay_comm)
            actual_profit = lay_profit - trade.back_stake
            trade.status = TradeStatus.LOST  # from back perspective, but overall should still profit

        trade.actual_profit = round(actual_profit, 2)
        trade.resolved_at = datetime.utcnow()

        # Update portfolio
        self.portfolio.bankroll += actual_profit
        self.portfolio.total_pnl += actual_profit
        if actual_profit > 0:
            self.portfolio.winning_trades += 1
        else:
            self.portfolio.losing_trades += 1
        self.portfolio.update_drawdown()

        # Move from open to closed
        self.portfolio.open_positions.remove(trade)
        self.portfolio.closed_positions.append(trade)

        # Log update
        self._log_trade(trade)

        logger.info(
            f"TRADE RESOLVED: {trade.id} | "
            f"Selection {'WON' if selection_won else 'LOST'} | "
            f"Actual P&L: £{actual_profit:.2f} | "
            f"Bankroll: £{self.portfolio.bankroll:.2f}"
        )

        return trade

    def auto_resolve_arb(self, trade_id: str) -> Optional[PaperTrade]:
        """
        For a true arb, the profit is guaranteed regardless of outcome.
        We resolve with the expected profit directly.
        """
        trade = None
        for t in self.portfolio.open_positions:
            if t.id == trade_id:
                trade = t
                break

        if not trade:
            return None

        trade.actual_profit = trade.expected_profit
        trade.status = TradeStatus.WON
        trade.resolved_at = datetime.utcnow()

        self.portfolio.bankroll += trade.expected_profit
        self.portfolio.total_pnl += trade.expected_profit
        self.portfolio.winning_trades += 1
        self.portfolio.update_drawdown()

        self.portfolio.open_positions.remove(trade)
        self.portfolio.closed_positions.append(trade)

        self._log_trade(trade)
        return trade

    def get_portfolio_summary(self) -> dict:
        """Return a summary of current portfolio state."""
        return {
            "bankroll": round(self.portfolio.bankroll, 2),
            "initial_bankroll": STRATEGY.initial_bankroll,
            "total_pnl": round(self.portfolio.total_pnl, 2),
            "total_pnl_pct": round(
                (self.portfolio.total_pnl / STRATEGY.initial_bankroll) * 100, 2
            ),
            "total_trades": self.portfolio.total_trades,
            "winning_trades": self.portfolio.winning_trades,
            "losing_trades": self.portfolio.losing_trades,
            "win_rate": (
                round(
                    self.portfolio.winning_trades
                    / max(
                        self.portfolio.winning_trades + self.portfolio.losing_trades,
                        1,
                    )
                    * 100,
                    1,
                )
            ),
            "open_positions": len(self.portfolio.open_positions),
            "peak_bankroll": round(self.portfolio.peak_bankroll, 2),
            "max_drawdown_pct": round(self.portfolio.max_drawdown * 100, 2),
        }

    def _log_trade(self, trade: PaperTrade):
        """Append trade to JSONL log file."""
        try:
            with open(STRATEGY.trades_log_path, "a") as f:
                f.write(trade.to_json() + "\n")
        except IOError as e:
            logger.error(f"Failed to log trade: {e}")

    def log_snapshot(self, data: dict):
        """Log an odds snapshot or scan result."""
        try:
            data["_timestamp"] = datetime.utcnow().isoformat()
            with open(STRATEGY.snapshots_path, "a") as f:
                f.write(json.dumps(data) + "\n")
        except IOError as e:
            logger.error(f"Failed to log snapshot: {e}")
