# Cross-Exchange Arbitrage Scanner & Paper Trader

A Python system that monitors odds across **Betfair Exchange** and **Smarkets** in real-time, detects pricing discrepancies (arbitrage opportunities), and executes paper trades to track simulated P&L.

## What It Does

1. **Fetches events** from both Betfair and Smarkets APIs
2. **Fuzzy-matches** events, markets, and runners across exchanges (different naming conventions)
3. **Polls odds** at configurable intervals (default: 5 seconds)
4. **Detects arbitrage** where Back price on exchange A > Lay price on exchange B (after commissions)
5. **Paper trades** opportunities, tracking bankroll, P&L, win rate, and drawdown
6. **Logs everything** to JSONL files for post-session analysis
7. **Displays a live terminal dashboard** showing odds, opportunities, and portfolio state

## Architecture

```
config.py          — All credentials, strategy params, and thresholds
models.py          — Data classes: RunnerOdds, ArbOpportunity, PaperTrade, etc.
betfair_client.py  — Betfair API wrapper (betfairlightweight)
smarkets_client.py — Smarkets REST API client (prices in basis points → decimal)
matcher.py         — Fuzzy event/runner matching across exchanges
arb_engine.py      — Arbitrage detection with commission-aware maths
paper_trader.py    — Paper trading engine with portfolio tracking
cooldown.py        — Prevents duplicate trades on same runner (configurable timer)
main.py            — Live scanner (requires API credentials)
simulate.py        — Simulation mode (no credentials needed)
dashboard.py       — Flask web dashboard (http://localhost:5050)
analyse.py         — Post-session trade analysis
```

## Quick Start

### 1. Simulation Mode (no credentials needed)

```bash
cd exchange_arb
pip install betfairlightweight requests flask
python simulate.py
```

This generates synthetic odds data that mimics real cross-exchange pricing behaviour, including occasional arbitrage opportunities from simulated pricing lags. It's the fastest way to see the system in action.

### 1b. Web Dashboard (optional, runs alongside scanner)

```bash
# Terminal 1:
python dashboard.py    # starts at http://localhost:5050

# Terminal 2:
python simulate.py     # or python main.py
```

The dashboard auto-refreshes every 3 seconds, showing your equity curve, trade log, P&L, and win rate.

### 2. Live Paper Trading (requires API credentials)

#### Betfair Setup
1. Create a Betfair account at [betfair.com](https://www.betfair.com)
2. Get an API App Key: [developer.betfair.com](https://developer.betfair.com/)
3. Generate SSL certificates: [Betfair cert guide](https://docs.developer.betfair.com/display/1smk3cen4v3lu3yomq5qye0ni/Non-Interactive+(bot)+login)
4. Place `.crt` and `.key` files in a `certs/` directory

#### Smarkets Setup
1. Create a Smarkets account at [smarkets.com](https://smarkets.com)
2. Get an API token from [docs.smarkets.com](https://docs.smarkets.com/)

#### Configure & Run
```bash
# Option A: Environment variables
export BETFAIR_USERNAME="your_username"
export BETFAIR_PASSWORD="your_password"
export BETFAIR_APP_KEY="your_app_key"
export BETFAIR_CERTS_DIR="./certs"
export SMARKETS_API_TOKEN="your_token"

# Option B: Edit config.py directly

# Run
python main.py
```

### 3. Analyse Results

```bash
python analyse.py
```

## How the Arbitrage Maths Works

For a cross-exchange arb (Back on exchange A, Lay on exchange B, same selection):

**If the selection WINS:**
```
Profit = BackStake × (BackPrice - 1) × (1 - BackCommission) - LayStake × (LayPrice - 1)
```

**If the selection LOSES:**
```
Profit = LayStake × (1 - LayCommission) - BackStake
```

Setting both equal and solving for the optimal `LayStake/BackStake` ratio gives a **guaranteed profit** regardless of outcome. The system only trades when the net edge (after both exchanges' commissions) exceeds `min_edge_pct` (default: 2%).

## Configuration

Key parameters in `config.py`:

| Parameter | Default | Description |
|-----------|---------|-------------|
| `min_edge_pct` | 2.0 | Minimum net edge (%) to trigger a trade |
| `betfair_commission` | 0.05 | Betfair commission rate (5%) |
| `smarkets_commission` | 0.02 | Smarkets commission rate (2%) |
| `initial_bankroll` | 1000 | Starting paper bankroll (GBP) |
| `max_stake` | 50 | Maximum stake per leg |
| `scan_interval_seconds` | 5.0 | Polling frequency |
| `event_type_ids` | ["1","2"] | Sports (1=Soccer, 2=Tennis) |
| `hours_until_start` | 24 | Look-ahead window |

## Transitioning to Real Trading

When you're confident in the system's performance:

1. Lower `min_edge_pct` gradually to see more (riskier) opportunities
2. Run parallel: paper + real with tiny stakes (£2 minimum on Betfair)
3. The `betfair_client.py` already has all the methods needed for real order placement — you just need to call `client.betting.place_orders()` instead of the paper trader
4. Consider latency: co-locate your server or use a VPS near the exchange servers

## Important Notes

- **This is for educational/research purposes.** Arbing between exchanges is legal in the UK but be aware that bookmakers (not exchanges) may limit accounts.
- **Betfair and Smarkets are exchanges** — they do not limit winning traders.
- **Smarkets has a void policy** — bets matched at prices >15% away from fair value can be voided. Be cautious with extreme mispricings.
- **Commissions eat into edges** — Betfair's 5% is significant; consider applying for their discount programme.
- **Liquidity matters** — simulated stakes may not be available in real markets, especially on Smarkets for less popular events.
