"""
Configuration for Cross-Exchange Arbitrage Scanner & Paper Trader.
Fill in your API credentials before running.
"""
from dataclasses import dataclass, field
from typing import Optional
import os


# ──────────────────────────────────────────────
# BETFAIR CREDENTIALS
# Get your app key: https://developer.betfair.com/
# Generate SSL certs: https://docs.developer.betfair.com/display/1smk3cen4v3lu3yomq5qye0ni/Non-Interactive+(bot)+login
# ──────────────────────────────────────────────
BETFAIR_USERNAME = os.environ.get("BETFAIR_USERNAME", "YOUR_USERNAME")
BETFAIR_PASSWORD = os.environ.get("BETFAIR_PASSWORD", "YOUR_PASSWORD")
BETFAIR_APP_KEY = os.environ.get("BETFAIR_APP_KEY", "YOUR_APP_KEY")
BETFAIR_CERTS_DIR = os.environ.get("BETFAIR_CERTS_DIR", "./certs")
# Set to True if you don't have SSL certs (less secure, requires manual login)
BETFAIR_INTERACTIVE_LOGIN = True

# ──────────────────────────────────────────────
# SMARKETS CREDENTIALS
# Get your API token: https://docs.smarkets.com/
# ──────────────────────────────────────────────
SMARKETS_API_TOKEN = os.environ.get("SMARKETS_API_TOKEN", "YOUR_SMARKETS_TOKEN")
SMARKETS_BASE_URL = "https://api.smarkets.com/v3"

# ──────────────────────────────────────────────
# STRATEGY PARAMETERS
# ──────────────────────────────────────────────

@dataclass
class StrategyConfig:
    # Minimum implied-probability edge (%) to trigger a paper trade
    # e.g. 2.0 means we need a 2% edge after commissions
    min_edge_pct: float = 2.0

    # Exchange commissions (fraction, not percent)
    betfair_commission: float = 0.05   # 5% on winnings (standard; can be lower with discounts)
    smarkets_commission: float = 0.02  # 2% on winnings (flat rate)

    # Paper trading bankroll
    initial_bankroll: float = 1000.0   # GBP

    # Maximum stake per leg (GBP)
    max_stake: float = 50.0

    # Minimum stake per leg (GBP)
    min_stake: float = 2.0

    # Default stake sizing: fraction of bankroll per opportunity
    kelly_fraction: float = 0.25  # quarter-Kelly for safety

    # Maximum number of concurrent open positions
    max_open_positions: int = 10

    # Scan interval in seconds (how often to poll APIs)
    scan_interval_seconds: float = 5.0

    # Sports to monitor (Betfair event type IDs)
    # 1=Soccer, 2=Tennis, 4=Cricket, 7=Horse Racing, 7522=Basketball
    event_type_ids: list = field(default_factory=lambda: ["1", "2"])

    # Only scan markets going in-play within N hours
    hours_until_start: int = 24

    # Log level
    log_level: str = "INFO"

    # Data persistence
    trades_log_path: str = "data/paper_trades.jsonl"
    snapshots_path: str = "data/odds_snapshots.jsonl"


STRATEGY = StrategyConfig()
