"""
Data models used across the system.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from typing import Optional
import json
import uuid


class Exchange(str, Enum):
    BETFAIR = "betfair"
    SMARKETS = "smarkets"


class Side(str, Enum):
    BACK = "back"
    LAY = "lay"


class TradeStatus(str, Enum):
    OPEN = "open"
    WON = "won"
    LOST = "lost"
    VOID = "void"


@dataclass
class RunnerOdds:
    """Odds snapshot for a single runner/selection on one exchange."""
    exchange: Exchange
    market_id: str
    selection_id: str
    runner_name: str
    best_back_price: Optional[float] = None  # decimal odds
    best_back_size: Optional[float] = None
    best_lay_price: Optional[float] = None
    best_lay_size: Optional[float] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)

    @property
    def back_implied_prob(self) -> Optional[float]:
        if self.best_back_price and self.best_back_price > 0:
            return 1.0 / self.best_back_price
        return None

    @property
    def lay_implied_prob(self) -> Optional[float]:
        if self.best_lay_price and self.best_lay_price > 0:
            return 1.0 / self.best_lay_price
        return None


@dataclass
class MatchedMarket:
    """A market that has been matched across two exchanges."""
    event_name: str
    market_name: str
    betfair_market_id: str
    smarkets_market_id: str
    start_time: Optional[datetime] = None
    sport: str = ""


@dataclass
class ArbOpportunity:
    """A detected arbitrage or edge opportunity."""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    timestamp: datetime = field(default_factory=datetime.utcnow)
    matched_market: Optional[MatchedMarket] = None
    runner_name: str = ""

    # The trade: BACK on one exchange, LAY on the other
    back_exchange: Exchange = Exchange.BETFAIR
    back_price: float = 0.0
    back_size_available: float = 0.0

    lay_exchange: Exchange = Exchange.SMARKETS
    lay_price: float = 0.0
    lay_size_available: float = 0.0

    # Calculated edge (after commissions)
    gross_edge_pct: float = 0.0
    net_edge_pct: float = 0.0

    # Recommended stakes
    back_stake: float = 0.0
    lay_stake: float = 0.0
    guaranteed_profit: float = 0.0

    def to_dict(self) -> dict:
        d = asdict(self)
        d["timestamp"] = self.timestamp.isoformat()
        if self.matched_market and self.matched_market.start_time:
            d["matched_market"]["start_time"] = self.matched_market.start_time.isoformat()
        return d


@dataclass
class PaperTrade:
    """A simulated trade for paper trading."""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    opportunity_id: str = ""
    timestamp: datetime = field(default_factory=datetime.utcnow)

    event_name: str = ""
    runner_name: str = ""

    back_exchange: Exchange = Exchange.BETFAIR
    back_price: float = 0.0
    back_stake: float = 0.0

    lay_exchange: Exchange = Exchange.SMARKETS
    lay_price: float = 0.0
    lay_stake: float = 0.0

    expected_profit: float = 0.0
    status: TradeStatus = TradeStatus.OPEN

    # Filled when resolved
    actual_profit: float = 0.0
    resolved_at: Optional[datetime] = None

    def to_dict(self) -> dict:
        d = asdict(self)
        d["timestamp"] = self.timestamp.isoformat()
        if self.resolved_at:
            d["resolved_at"] = self.resolved_at.isoformat()
        return d

    def to_json(self) -> str:
        return json.dumps(self.to_dict())


@dataclass
class PortfolioState:
    """Current state of the paper trading portfolio."""
    bankroll: float = 1000.0
    total_trades: int = 0
    winning_trades: int = 0
    losing_trades: int = 0
    total_pnl: float = 0.0
    open_positions: list = field(default_factory=list)  # list of PaperTrade
    closed_positions: list = field(default_factory=list)
    peak_bankroll: float = 1000.0
    max_drawdown: float = 0.0

    def update_drawdown(self):
        if self.bankroll > self.peak_bankroll:
            self.peak_bankroll = self.bankroll
        dd = (self.peak_bankroll - self.bankroll) / self.peak_bankroll
        if dd > self.max_drawdown:
            self.max_drawdown = dd
