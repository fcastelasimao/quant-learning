"""
Betfair Exchange client using betfairlightweight.
Fetches current market odds for configured sports.
"""
from __future__ import annotations
import logging
from datetime import datetime, timedelta
from typing import Optional

import betfairlightweight
from betfairlightweight.filters import market_filter, price_projection

from config import (
    BETFAIR_USERNAME,
    BETFAIR_PASSWORD,
    BETFAIR_APP_KEY,
    BETFAIR_CERTS_DIR,
    BETFAIR_INTERACTIVE_LOGIN,
    STRATEGY,
)
from models import Exchange, RunnerOdds

logger = logging.getLogger(__name__)


class BetfairClient:
    """Wrapper around betfairlightweight for fetching odds."""

    def __init__(self):
        self.client: Optional[betfairlightweight.APIClient] = None
        self._logged_in = False

    def login(self) -> bool:
        """Authenticate with Betfair API."""
        try:
            if BETFAIR_INTERACTIVE_LOGIN:
                self.client = betfairlightweight.APIClient(
                    username=BETFAIR_USERNAME,
                    password=BETFAIR_PASSWORD,
                    app_key=BETFAIR_APP_KEY,
                )
                self.client.login_interactive()
            else:
                self.client = betfairlightweight.APIClient(
                    username=BETFAIR_USERNAME,
                    password=BETFAIR_PASSWORD,
                    app_key=BETFAIR_APP_KEY,
                    certs=BETFAIR_CERTS_DIR,
                )
                self.client.login()

            self._logged_in = True
            logger.info("Betfair login successful")
            return True

        except Exception as e:
            logger.error(f"Betfair login failed: {e}")
            return False

    def keep_alive(self):
        """Refresh session token (call periodically, e.g. every 4 hours)."""
        if self.client and self._logged_in:
            try:
                self.client.keep_alive()
            except Exception as e:
                logger.warning(f"Betfair keep_alive failed: {e}")
                self.login()

    def get_events(self, event_type_ids: list[str] = None) -> list[dict]:
        """
        Get upcoming events for the configured sports.
        Returns list of dicts with event info.
        """
        if not self._logged_in:
            raise RuntimeError("Not logged in to Betfair")

        if event_type_ids is None:
            event_type_ids = STRATEGY.event_type_ids

        time_filter = {
            "from": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
            "to": (datetime.utcnow() + timedelta(hours=STRATEGY.hours_until_start)).strftime(
                "%Y-%m-%dT%H:%M:%SZ"
            ),
        }

        mf = market_filter(
            event_type_ids=event_type_ids,
            market_start_time=time_filter,
            in_play_only=False,
        )

        events = self.client.betting.list_events(filter=mf)
        results = []
        for ev in events:
            results.append(
                {
                    "event_id": ev.event.id,
                    "event_name": ev.event.name,
                    "country_code": ev.event.country_code,
                    "open_date": ev.event.open_date,
                    "market_count": ev.market_count,
                }
            )

        logger.info(f"Betfair: found {len(results)} events")
        return results

    def get_markets_for_event(self, event_id: str) -> list[dict]:
        """
        Get all markets for a specific event.
        Focuses on Match Odds / Moneyline type markets.
        """
        if not self._logged_in:
            raise RuntimeError("Not logged in to Betfair")

        mf = market_filter(
            event_ids=[event_id],
            market_types=["MATCH_ODDS", "WINNER", "MONEYLINE"],
        )

        catalogues = self.client.betting.list_market_catalogue(
            filter=mf,
            max_results=25,
            market_projection=[
                "RUNNER_DESCRIPTION",
                "MARKET_START_TIME",
                "EVENT",
                "COMPETITION",
            ],
        )

        results = []
        for cat in catalogues:
            runners = []
            for r in cat.runners:
                runners.append(
                    {
                        "selection_id": str(r.selection_id),
                        "runner_name": r.runner_name,
                        "sort_priority": r.sort_priority,
                    }
                )
            results.append(
                {
                    "market_id": cat.market_id,
                    "market_name": cat.market_name,
                    "market_start_time": cat.market_start_time,
                    "event_name": cat.event.name if cat.event else "",
                    "competition": cat.competition.name if cat.competition else "",
                    "runners": runners,
                }
            )

        return results

    def get_market_odds(self, market_ids: list[str]) -> list[RunnerOdds]:
        """
        Fetch current best back/lay prices for runners in given markets.
        Returns list of RunnerOdds.
        """
        if not self._logged_in:
            raise RuntimeError("Not logged in to Betfair")

        pp = price_projection(price_data=["EX_BEST_OFFERS"])

        # Betfair allows max ~40 market IDs per call
        all_odds = []
        for i in range(0, len(market_ids), 40):
            batch = market_ids[i : i + 40]
            market_books = self.client.betting.list_market_book(
                market_ids=batch, price_projection=pp
            )

            for book in market_books:
                for runner in book.runners:
                    if runner.status != "ACTIVE":
                        continue

                    best_back = None
                    best_back_size = None
                    best_lay = None
                    best_lay_size = None

                    if runner.ex and runner.ex.available_to_back:
                        top = runner.ex.available_to_back[0]
                        best_back = top.price
                        best_back_size = top.size

                    if runner.ex and runner.ex.available_to_lay:
                        top = runner.ex.available_to_lay[0]
                        best_lay = top.price
                        best_lay_size = top.size

                    odds = RunnerOdds(
                        exchange=Exchange.BETFAIR,
                        market_id=book.market_id,
                        selection_id=str(runner.selection_id),
                        runner_name="",  # filled later from catalogue
                        best_back_price=best_back,
                        best_back_size=best_back_size,
                        best_lay_price=best_lay,
                        best_lay_size=best_lay_size,
                        timestamp=datetime.utcnow(),
                    )
                    all_odds.append(odds)

        return all_odds

    def logout(self):
        if self.client and self._logged_in:
            try:
                self.client.logout()
            except Exception:
                pass
            self._logged_in = False
